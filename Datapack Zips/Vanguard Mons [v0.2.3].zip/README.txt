SETUP
+----+

Locate and place the .zip file in your resourcepack folder [Default = %appdata%/.minecraft/resourcepacks] [Modrith = %appdata%/com.modrinth.theseus/profiles/Cobblemon [Fabric]/resourcepacks]
Upon creating a world, add the .zip to the datapack list. Alternatively you can manually add them your world datapack folder [Default =%appdata%/.minecraft/saves/(NAMEOFWORLD)/datapacks] [Modrith = %appdata%/com.modrinth.theseus/profiles/Cobblemon [Fabric]/saves/(NAMEOFWORLD)/datapacks]

You can use http://mc-packs.net for hosting the resourcepack for your server.

Hope you enjoy the pack!

Credits
+-------+
# Credits for the creation of these pokemon can be found here: https://docs.google.com/spreadsheets/d/1D7s7XY2V1Uhqx7KjxYrlPwALvEqSzx-nMThLwb8qEGA/edit#gid=685889712
# Credits to pokemon
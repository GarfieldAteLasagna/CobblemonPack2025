Thanks for downloading the pack! I hope you enjoy it as much as I do.

To change outfits, use the following items on Incineroar: 

minecraft:leather_helmet -> Royal Mask Incineroar
minecraft:melon_slice -> Summer Incineroar
minecraft:shears -> Incineroar

Keep in mind that any items used to change outfits WILL be consumed upon use.

Royal Mask outfit design by Ficher.
Royal Mask model by AbstractJoker.
Summer Incineroar model and outfit by RedRibbon.
Animations by Lenkagari via CobbleMotion 1.2 resource pack.
Special thanks to Orion0333 for showing me what to do and helping me bugtest everything.

KNOWN BUGS: Changing from Summer to Royal Mask locks Incineroar in that outfit and it cannont be changed until you reload the save file.

NOTE: For Mega Showdown users, Incinium-Z currently doesn't work with costumed variants. This is a known issue and will be fixed as soon as I figure out a workaround.

To install the pack, make sure to copy the zip file to both the resourcepacks folder in your Minecraft instance and in the datapacks folder in your world's save data. 
This pack will work on older versions even if Minecraft says it doesn't, but you can change the pack_format number in the pack.mcmeta file if you want.

- 1 for 1.6.1 – 1.8.9
- 2 for 1.9 – 1.10.2
- 3 for 1.11 – 1.12.2
- 4 for 13 – 1.14.4
- 5 for 15 – 1.16.1
- 6 for 16.2 – 1.16.5
- 7 for 1.17 – 1.17.1
- 8 for 1.18 – 1.18.2
- 9 for 1.19 – 1.19.2
- 12 for 1.19.3
- 13 for 1.19.4
- 15 for 1.20 – 1.20.1
- 18 for 1.20.2
- 22 for 1.20.3 – 1.20.4
- 32 for 1.20.5 – 1.20.6
- 34 for 1.21 – 1.21.1
- 42 for 1.21.2 – 1.21.3
- 46 for 1.21.4
- 55 for 1.21.5

Please make sure to credit myself and all individuals involved in the creation of this pack before using it in your own datapack.

